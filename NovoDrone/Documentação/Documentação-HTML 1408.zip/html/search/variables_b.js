var searchData=
[
  ['usando_170',['usando',['../classControleSerial_ac4bc1546af29c74855936fd912f839b4.html#ac4bc1546af29c74855936fd912f839b4',1,'ControleSerial']]]
];
