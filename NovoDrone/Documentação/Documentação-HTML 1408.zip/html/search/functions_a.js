var searchData=
[
  ['sair_131',['sair',['../classPassaBaixa_ade4ffdfb98cbcb49a769266a0951b0f6.html#ade4ffdfb98cbcb49a769266a0951b0f6',1,'PassaBaixa']]],
  ['setamostragem_132',['setAmostragem',['../classPassaBaixa_ac029b8b38c4488f9e92fa0459fd5cc0d.html#ac029b8b38c4488f9e92fa0459fd5cc0d',1,'PassaBaixa']]],
  ['setangulo_133',['setAngulo',['../classRegistro_a150321614d788f8b0ce1d27bd583e944.html#a150321614d788f8b0ce1d27bd583e944',1,'Registro']]],
  ['setfrequencia_134',['setFrequencia',['../classPassaBaixa_ab59c37797cd8d7494e8b72a7217e7208.html#ab59c37797cd8d7494e8b72a7217e7208',1,'PassaBaixa']]],
  ['setminimo_135',['setMinimo',['../classMotor_af87c5b5980d648facfcdc838e2b7583d.html#af87c5b5980d648facfcdc838e2b7583d',1,'Motor']]],
  ['setmotor_136',['setMotor',['../classDrone_a13077939859b798bd51c039e4dab2413.html#a13077939859b798bd51c039e4dab2413',1,'Drone']]],
  ['setporta_137',['setPorta',['../classVoltimetro_a3ad60d111e56e8b4f99204edcbfbdc12.html#a3ad60d111e56e8b4f99204edcbfbdc12',1,'Voltimetro']]],
  ['setserial_138',['setSerial',['../classControleSerial_a29395e48789c54171d44b9a6378e3785.html#a29395e48789c54171d44b9a6378e3785',1,'ControleSerial']]],
  ['settensao_139',['setTensao',['../classRegistro_a85cca12cf4985a9b22835e24a9ad6756.html#a85cca12cf4985a9b22835e24a9ad6756',1,'Registro']]],
  ['setup_140',['setup',['../4SetupLoop_8ino_a4fc01d736fe50cf5b977f755b675f11d.html#a4fc01d736fe50cf5b977f755b675f11d',1,'4SetupLoop.ino']]],
  ['setvelocidade_141',['setVelocidade',['../classRegistro_afcb4cc9f2cb3643c79b81289de9fef64.html#afcb4cc9f2cb3643c79b81289de9fef64',1,'Registro']]]
];
