var indexSectionsWithContent =
{
  0: "1234acdefgiklmnopqrstuvy",
  1: "cdimprv",
  2: "1234n",
  3: "acdegilmprsv",
  4: "acefikmprstuvy",
  5: "r",
  6: "ikloqrsv"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "related",
  6: "defines"
};

var indexSectionLabels =
{
  0: "Tudo",
  1: "Classes",
  2: "Ficheiros",
  3: "Funções",
  4: "Variáveis",
  5: "Amigos",
  6: "Macros"
};

