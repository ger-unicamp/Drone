var searchData=
[
  ['variaveispid_79',['VariaveisPID',['../structVariaveisPID.html',1,'']]],
  ['varpidpitch_80',['varPIDPitch',['../classDrone_aa469eedc232351a3761b07cf8a75794c.html#aa469eedc232351a3761b07cf8a75794c',1,'Drone']]],
  ['vel0_81',['vel0',['../classRegistro_a00eebbd3696386785de8b82989e4d0c9.html#a00eebbd3696386785de8b82989e4d0c9',1,'Registro']]],
  ['vel1_82',['vel1',['../classRegistro_a225ad99ae1066ea77b6367749229072b.html#a225ad99ae1066ea77b6367749229072b',1,'Registro']]],
  ['vel2_83',['vel2',['../classRegistro_a31c24502030747178331214a52f51279.html#a31c24502030747178331214a52f51279',1,'Registro']]],
  ['vel3_84',['vel3',['../classRegistro_a33b4c089f632f389093f71960dbf3bd3.html#a33b4c089f632f389093f71960dbf3bd3',1,'Registro']]],
  ['velocidade_85',['velocidade',['../classMotor_a320ea1878a4f2040501c65d34a473abb.html#a320ea1878a4f2040501c65d34a473abb',1,'Motor']]],
  ['voltimetro_86',['Voltimetro',['../classVoltimetro.html',1,'Voltimetro'],['../classDrone_a0461c72d67cc892a91eabb0c5a909793.html#a0461c72d67cc892a91eabb0c5a909793',1,'Drone::voltimetro()'],['../classVoltimetro_ae5c81dfba1c87ce95c704c301a4995ca.html#ae5c81dfba1c87ce95c704c301a4995ca',1,'Voltimetro::Voltimetro()']]],
  ['voo_87',['VOO',['../NovoDrone_8ino_a1a2b6514ea69d1b11b99840f39553e11.html#a1a2b6514ea69d1b11b99840f39553e11',1,'NovoDrone.ino']]]
];
