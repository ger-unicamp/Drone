var searchData=
[
  ['minimo_158',['minimo',['../classMotor_a10cf085bfd4133d3293aefb21d59ca5b.html#a10cf085bfd4133d3293aefb21d59ca5b',1,'Motor']]],
  ['motor_159',['motor',['../classDrone_a3df0381d111008d42094d62b67345411.html#a3df0381d111008d42094d62b67345411',1,'Drone']]]
];
