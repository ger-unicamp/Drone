var searchData=
[
  ['minimo_42',['minimo',['../classMotor_a10cf085bfd4133d3293aefb21d59ca5b.html#a10cf085bfd4133d3293aefb21d59ca5b',1,'Motor']]],
  ['motor_43',['Motor',['../classMotor.html',1,'Motor'],['../classDrone_a3df0381d111008d42094d62b67345411.html#a3df0381d111008d42094d62b67345411',1,'Drone::motor()'],['../classMotor_adefa57614d01bd62b8960db5a3e45110.html#adefa57614d01bd62b8960db5a3e45110',1,'Motor::Motor()']]]
];
