var searchData=
[
  ['registro_163',['registro',['../classDrone_a37e0d1480564fb12da4e8951b7f44f6d.html#a37e0d1480564fb12da4e8951b7f44f6d',1,'Drone']]],
  ['roll_164',['roll',['../classInercial_a26fd84d522945b6038221d9e38c7cc39.html#a26fd84d522945b6038221d9e38c7cc39',1,'Inercial::roll()'],['../classRegistro_a813d79a6be84028a25ee3abbb605e1bd.html#a813d79a6be84028a25ee3abbb605e1bd',1,'Registro::roll()']]]
];
