var searchData=
[
  ['pidpitch_160',['pidPitch',['../classDrone_ae0484d7820c4f676db1d4cb9d4a0b1e5.html#ae0484d7820c4f676db1d4cb9d4a0b1e5',1,'Drone']]],
  ['pitch_161',['pitch',['../classInercial_a282e7d4378d4a18a805b8980295ac86c.html#a282e7d4378d4a18a805b8980295ac86c',1,'Inercial::pitch()'],['../classRegistro_ad679087d88e267f46aa86414c0e1131e.html#ad679087d88e267f46aa86414c0e1131e',1,'Registro::pitch()']]],
  ['porta_162',['porta',['../classVoltimetro_a7f40325aaddc75ec8e13cdd34400047d.html#a7f40325aaddc75ec8e13cdd34400047d',1,'Voltimetro']]]
];
