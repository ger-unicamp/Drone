var searchData=
[
  ['kdpitch_181',['KDpitch',['../NovoDrone_8ino_a4f68d3a7a63c34cb650fc042970005e5.html#a4f68d3a7a63c34cb650fc042970005e5',1,'NovoDrone.ino']]],
  ['kipitch_182',['KIpitch',['../NovoDrone_8ino_a640231815e3b3a2a37f7313dea760e14.html#a640231815e3b3a2a37f7313dea760e14',1,'NovoDrone.ino']]],
  ['kppitch_183',['KPpitch',['../NovoDrone_8ino_a8fa6f9ad15dac0a263ae161409ce19c5.html#a8fa6f9ad15dac0a263ae161409ce19c5',1,'NovoDrone.ino']]]
];
