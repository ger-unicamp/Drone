var searchData=
[
  ['amostragem_143',['amostragem',['../classPassaBaixa_af03bf92a0f7834d9a00d243d5df81fd3.html#af03bf92a0f7834d9a00d243d5df81fd3',1,'PassaBaixa']]]
];
