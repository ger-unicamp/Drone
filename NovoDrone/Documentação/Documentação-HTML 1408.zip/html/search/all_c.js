var searchData=
[
  ['leitura_38',['leitura',['../classInercial_a1b534bc702a097e3544b991e2bacfc38.html#a1b534bc702a097e3544b991e2bacfc38',1,'Inercial::leitura()'],['../classVoltimetro_aaa542593e23527970698c8ecccfa393d.html#aaa542593e23527970698c8ecccfa393d',1,'Voltimetro::leitura()'],['../classDrone_a1b534bc702a097e3544b991e2bacfc38.html#a1b534bc702a097e3544b991e2bacfc38',1,'Drone::leitura()']]],
  ['liga_39',['LIGA',['../NovoDrone_8ino_abe665826021d3fee71a276eb61e29413.html#abe665826021d3fee71a276eb61e29413',1,'NovoDrone.ino']]],
  ['ligar_40',['ligar',['../classMotor_aa64df8a8b7d0e3fee175ce46e0a620c9.html#aa64df8a8b7d0e3fee175ce46e0a620c9',1,'Motor::ligar()'],['../classDrone_aa64df8a8b7d0e3fee175ce46e0a620c9.html#aa64df8a8b7d0e3fee175ce46e0a620c9',1,'Drone::ligar()']]],
  ['loop_41',['loop',['../4SetupLoop_8ino_afe461d27b9c48d5921c00d521181f12f.html#afe461d27b9c48d5921c00d521181f12f',1,'4SetupLoop.ino']]]
];
