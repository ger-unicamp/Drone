var searchData=
[
  ['registro_179',['Registro',['../classMotor_a9205444021fc8aa87162996750e6f6af.html#a9205444021fc8aa87162996750e6f6af',1,'Motor::Registro()'],['../classInercial_a9205444021fc8aa87162996750e6f6af.html#a9205444021fc8aa87162996750e6f6af',1,'Inercial::Registro()'],['../classVoltimetro_a9205444021fc8aa87162996750e6f6af.html#a9205444021fc8aa87162996750e6f6af',1,'Voltimetro::Registro()']]]
];
