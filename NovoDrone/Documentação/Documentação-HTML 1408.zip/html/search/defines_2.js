var searchData=
[
  ['liga_184',['LIGA',['../NovoDrone_8ino_abe665826021d3fee71a276eb61e29413.html#abe665826021d3fee71a276eb61e29413',1,'NovoDrone.ino']]]
];
