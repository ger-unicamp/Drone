var searchData=
[
  ['registro_58',['Registro',['../classRegistro.html',1,'Registro'],['../classDrone_a37e0d1480564fb12da4e8951b7f44f6d.html#a37e0d1480564fb12da4e8951b7f44f6d',1,'Drone::registro()'],['../classMotor_a9205444021fc8aa87162996750e6f6af.html#a9205444021fc8aa87162996750e6f6af',1,'Motor::Registro()'],['../classInercial_a9205444021fc8aa87162996750e6f6af.html#a9205444021fc8aa87162996750e6f6af',1,'Inercial::Registro()'],['../classVoltimetro_a9205444021fc8aa87162996750e6f6af.html#a9205444021fc8aa87162996750e6f6af',1,'Voltimetro::Registro()'],['../classRegistro_af8a2db6253c4bbfa8d56abb8625a7397.html#af8a2db6253c4bbfa8d56abb8625a7397',1,'Registro::Registro()']]],
  ['roda_59',['RODA',['../NovoDrone_8ino_ab6ec3c0f6eca96d818b50d3985e3bd06.html#ab6ec3c0f6eca96d818b50d3985e3bd06',1,'NovoDrone.ino']]],
  ['roll_60',['roll',['../classInercial_a26fd84d522945b6038221d9e38c7cc39.html#a26fd84d522945b6038221d9e38c7cc39',1,'Inercial::roll()'],['../classRegistro_a813d79a6be84028a25ee3abbb605e1bd.html#a813d79a6be84028a25ee3abbb605e1bd',1,'Registro::roll()']]]
];
