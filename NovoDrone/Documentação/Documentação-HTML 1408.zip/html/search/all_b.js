var searchData=
[
  ['kd_32',['kd',['../structVariaveisPID_a1cf17dd45e85748457863776dcb28335.html#a1cf17dd45e85748457863776dcb28335',1,'VariaveisPID']]],
  ['kdpitch_33',['KDpitch',['../NovoDrone_8ino_a4f68d3a7a63c34cb650fc042970005e5.html#a4f68d3a7a63c34cb650fc042970005e5',1,'NovoDrone.ino']]],
  ['ki_34',['ki',['../structVariaveisPID_a23e09706a4abb026e1de279c4904e926.html#a23e09706a4abb026e1de279c4904e926',1,'VariaveisPID']]],
  ['kipitch_35',['KIpitch',['../NovoDrone_8ino_a640231815e3b3a2a37f7313dea760e14.html#a640231815e3b3a2a37f7313dea760e14',1,'NovoDrone.ino']]],
  ['kp_36',['kp',['../structVariaveisPID_ac6390bc2d074992cc6ca37d132a5262d.html#ac6390bc2d074992cc6ca37d132a5262d',1,'VariaveisPID']]],
  ['kppitch_37',['KPpitch',['../NovoDrone_8ino_a8fa6f9ad15dac0a263ae161409ce19c5.html#a8fa6f9ad15dac0a263ae161409ce19c5',1,'NovoDrone.ino']]]
];
