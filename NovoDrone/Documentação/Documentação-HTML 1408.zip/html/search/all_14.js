var searchData=
[
  ['tensao_77',['tensao',['../classVoltimetro_afeb7619f8d9433b6054ce06f42404639.html#afeb7619f8d9433b6054ce06f42404639',1,'Voltimetro::tensao()'],['../classRegistro_ac1a903efb8ae64bcd8982bf29554b0ea.html#ac1a903efb8ae64bcd8982bf29554b0ea',1,'Registro::tensao()']]]
];
