var searchData=
[
  ['getpitch_111',['getPitch',['../classInercial_a550128a969585b8a64a53ecc384ec361.html#a550128a969585b8a64a53ecc384ec361',1,'Inercial']]],
  ['getroll_112',['getRoll',['../classInercial_a80829684c889d9492db5f72006a8afbb.html#a80829684c889d9492db5f72006a8afbb',1,'Inercial']]],
  ['getyaw_113',['getYaw',['../classInercial_a4829acab810a443dd7001a73a20b83e5.html#a4829acab810a443dd7001a73a20b83e5',1,'Inercial']]],
  ['girar_114',['girar',['../classMotor_a9398d9877adc23d358cac4be04763c68.html#a9398d9877adc23d358cac4be04763c68',1,'Motor::girar(int diferenca)'],['../classMotor_adf521ee1342818088ff677fe1474b393.html#adf521ee1342818088ff677fe1474b393',1,'Motor::girar()']]]
];
